package com.seu.scrm.service;

/**
 * Created by chenxiaosuo on 2019/3/5.
 */
public interface ReportService {

    String queryReport();
}
